package com.dvwatchfaces.superman.lite;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ScrollView;
import android.widget.TextView;

/** Запрос разрешений и короткий статус. */
public class MainActivity extends Activity {

    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.BLACK);
        tv = new TextView(this);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(14f);
        tv.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = (int) (getResources().getDisplayMetrics().density * 36);
        tv.setPadding(p, p, p, p * 2);
        sv.addView(tv);
        setContentView(sv);
        if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CALENDAR,
                    Manifest.permission.READ_CONTACTS}, 1);
        }
        refresh();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        new Thread(() -> {
            try { HolidayMask.refreshOnline(this); } catch (Throwable ignored) { }
            runOnUiThread(this::refresh);
        }).start();
    }

    private void refresh() {
        HolidayMask.Result r = HolidayMask.compute(this);
        StringBuilder sb = new StringBuilder("Праздники и дни рождения\n\n");
        if (r.permission) {
            sb.append("Выходные на неделе: ").append(r.holidays).append('\n');
            sb.append("Дни рождения: ").append(r.birthdays).append('\n');
            sb.append("Праздники онлайн: ").append(r.online ? "есть" : "нет данных");
        } else {
            sb.append("Разрешите доступ к календарю и контактам.");
        }
        tv.setText(sb.toString());
    }
}
