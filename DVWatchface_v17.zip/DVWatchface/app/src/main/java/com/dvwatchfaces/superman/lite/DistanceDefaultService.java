package com.dvwatchfaces.superman.lite;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.wear.watchface.complications.data.ComplicationData;
import androidx.wear.watchface.complications.data.ComplicationText;
import androidx.wear.watchface.complications.data.ComplicationType;
import androidx.wear.watchface.complications.data.EmptyComplicationData;
import androidx.wear.watchface.complications.data.PlainComplicationText;
import androidx.wear.watchface.complications.data.ShortTextComplicationData;
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceService;
import androidx.wear.watchface.complications.datasource.ComplicationRequest;

/** Источник по умолчанию: отдаёт «пусто», и циферблат рисует свой встроенный показатель. */
public class DistanceDefaultService extends ComplicationDataSourceService {

    @Nullable
    @Override
    public ComplicationData getPreviewData(@NonNull ComplicationType type) {
        return new ShortTextComplicationData.Builder(
                new PlainComplicationText.Builder("4,64").build(),
                ComplicationText.EMPTY).build();
    }

    @Override
    public void onComplicationRequest(@NonNull ComplicationRequest request,
                                      @NonNull ComplicationRequestListener listener) {
        try {
            listener.onComplicationData(new EmptyComplicationData());
        } catch (android.os.RemoteException ignored) {
        }
    }
}
